﻿using System;

namespace BulkyBook.Models
{
    public class Class1
    {
    }
}

﻿using System;

namespace BulkyBook.Utility
{
    public class Class1
    {
    }
}
